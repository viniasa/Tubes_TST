<form action="/updatePassword" method="post">
    <label for="password">New Password</label>
    <input type="password" name="password" id="password" required>
    <button type="submit">Update Password</button>
</form>
