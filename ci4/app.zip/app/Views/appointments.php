<h1>Available Consultation Schedules</h1>

<?php if (!empty($appointments) && is_array($appointments)): ?>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Date</th>
            <th>Time</th>
            <th>Action</th>
        </tr>
        <?php foreach ($appointments as $appointment): ?>
            <tr>
                <td><?= esc($appointment['id']) ?></td>
                <td><?= esc($appointment['date']) ?></td>
                <td><?= esc($appointment['time']) ?></td>
                <td><a href="<?= base_url('appointments/create') ?>">Book</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php else: ?>
    <h3>No Available Appointments</h3>
    <p>Currently, there are no available schedules for consultation.</p>
<?php endif; ?>
