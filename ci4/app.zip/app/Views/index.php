<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Awal</title>
</head>
<body>
    <h1>Selamat Datang di Aplikasi Kami</h1>

    <!-- Menampilkan validasi dan kesalahan -->
    <?php if (isset($validation)): ?>
        <ul>
            <?php foreach ($validation->getErrors() as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <!-- Form Login -->
    <h2>Login</h2>
    <?php if (isset($error)): ?>
        <div style="color: red;"><?= esc($error) ?></div>
    <?php endif; ?>
    <form action="<?= site_url('auth/authenticate') ?>" method="post">
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Login</button>
    </form>

    <p>Belum punya akun? <a href="<?= site_url('auth/signUp') ?>">Daftar disini</a></p>
    <p><a href="<?= site_url('auth/forgotPassword') ?>">Lupa Password?</a></p>

    <hr>

    <!-- Form Sign Up -->
    <h2>Daftar Akun Baru</h2>
    <form action="<?= site_url('auth/register') ?>" method="post">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input type="password" name="confirm_password" placeholder="Konfirmasi Password" required><br>
        <button type="submit">Daftar</button>
    </form>

    <p>Sudah punya akun? <a href="<?= site_url('auth/login') ?>">Login disini</a></p>

    <hr>

    <!-- Form Forgot Password -->
    <h2>Lupa Password?</h2>
    <form action="<?= site_url('auth/resetPassword') ?>" method="post">
        <input type="email" name="email" placeholder="Email" required><br>
        <button type="submit">Kirim Link Reset</button>
    </form>

</body>
</html>

