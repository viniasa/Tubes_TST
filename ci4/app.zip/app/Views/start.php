<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <h1>Welcome to the Website</h1>

    <?php if (session()->get('isLoggedIn')): ?>
        <p>Welcome, <?= esc(session()->get('name')) ?>!</p>
        <a href="/logout">Logout</a>
    <?php else: ?>
        <p><a href="/login">Login</a> | <a href="/signup">Sign Up</a> | <a href="/forgot-password">Forgot Password</a></p>
    <?php endif; ?>

</body>
</html>
