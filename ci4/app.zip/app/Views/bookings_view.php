<h2>List of Booked Appointments</h2>

<?php if (!empty($bookedAppointments) && is_array($bookedAppointments)): ?>
    <table border="1">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Email</th>
                <th>Psychologist</th>
                <th>Schedule Date</th>
                <th>Schedule Time</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bookedAppointments as $appointment): ?>
                <tr>
                    <td><?= esc($appointment['user_name']) ?></td>
                    <td><?= esc($appointment['email']) ?></td>
                    <td><?= esc($appointment['psychologist_name']) ?></td>
                    <td><?= esc($appointment['schedule_date']) ?></td>
                    <td><?= esc($appointment['schedule_time']) ?></td>
                    <td><?= esc($appointment['status']) ?></td>
                    <td>
                        <!-- Tombol Cancel -->
                        <form action="/cancel-booking" method="post" style="display:inline;">
                            <input type="hidden" name="id" value="<?= esc($appointment['id']) ?>">
                            <button type="submit" onclick="return confirm('Are you sure you want to cancel this booking?')">Cancel</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No booked appointments found.</p>
<?php endif; ?>