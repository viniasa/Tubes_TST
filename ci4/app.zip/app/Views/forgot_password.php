<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password</title>
</head>
<body>
    <h1>Lupa Password?</h1>

    <?php if (isset($validation)): ?>
        <ul>
            <?php foreach ($validation->getErrors() as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div style="color: red;"><?= esc($error) ?></div>
    <?php endif; ?>

    <form action="<?= site_url('auth/resetPassword') ?>" method="post">
        <input type="email" name="email" placeholder="Email" required>
        <button type="submit">Reset Password</button>
    </form>

    <a href="<?= site_url('auth/login') ?>">Kembali ke Login</a>
</body>
</html>
