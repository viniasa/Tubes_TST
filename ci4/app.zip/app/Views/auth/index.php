<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px auto;
            max-width: 500px;
        }
        h1 {
            margin-bottom: 30px;
        }
        a {
            display: inline-block;
            margin: 10px 0;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Welcome to the Authentication System</h1>
    <p>Choose an option below:</p>
    <div>
        <a href="/auth/register">Sign Up</a><br>
        <a href="/auth/login">Login</a><br>
        <a href="/auth/forgetPassword">Forgot Password</a><br>
        <a href="/auth/logout">Logout</a>
    </div>
</body>
</html>
