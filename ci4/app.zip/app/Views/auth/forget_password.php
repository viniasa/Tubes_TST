<h1>Forget Password</h1>
<form method="post" action="/auth/processForgetPassword">
    <input type="email" name="email" placeholder="Email" required>
    <button type="submit">Send Reset Token</button>
</form>
