<h1>Reset Password</h1>
<form method="post" action="/auth/processResetPassword">
    <input type="hidden" name="token" value="<?= $token ?>">
    <input type="password" name="password" placeholder="New Password" required>
    <button type="submit">Reset Password</button>
</form>
