<!-- update_booking_view.php -->
<h2>Update Booking</h2>

<form action="/submit-update-booking" method="post">
    <input type="hidden" name="id" value="<?= esc($booking['id']) ?>">

    <label for="user_name">User Name:</label>
    <input type="text" name="user_name" id="user_name" value="<?= esc($booking['user_name']) ?>" required><br>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" value="<?= esc($booking['email']) ?>" required><br>

    <label for="psychologist_name">Psychologist:</label>
    <select name="psychologist_name" id="psychologist_name" required>
        <option value="">-- Select Psychologist --</option>
        <?php foreach ($availablePsychologists as $psychologist): ?>
            <option value="<?= esc($psychologist['name']) ?>" <?= $psychologist['name'] === $booking['psychologist_name'] ? 'selected' : '' ?>>
                <?= esc($psychologist['name']) ?>
            </option>
        <?php endforeach; ?>
    </select><br>

    <label for="schedule_date">Schedule Date:</label>
    <select name="schedule_date" id="schedule_date" required>
        <option value="">-- Select Date --</option>
        <?php foreach ($availableSchedules as $schedule): ?>
            <option value="<?= esc($schedule['date']) ?>" <?= $schedule['date'] === $booking['schedule_date'] ? 'selected' : '' ?>>
                <?= esc($schedule['date']) ?>
            </option>
        <?php endforeach; ?>
    </select><br>

    <label for="schedule_time">Schedule Time:</label>
    <select name="schedule_time" id="schedule_time" required>
        <option value="">-- Select Time --</option>
        <?php foreach ($availableTimes as $time): ?>
            <option value="<?= esc($time['time']) ?>" <?= $time['time'] === $booking['schedule_time'] ? 'selected' : '' ?>>
                <?= esc($time['time']) ?>
            </option>
        <?php endforeach; ?>
    </select><br>

    <button type="submit">Submit</button>
    <a href="/bookings">Cancel</a>
</form>
