<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Konsultasi Psikolog</title>
</head>
<body>

    <h1>Jadwal Konsultasi Psikolog yang Tersedia</h1>

    <?php if (session()->getFlashdata('success')): ?>
        <p style="color: green;"><?= session()->getFlashdata('success') ?></p>
    <?php elseif (session()->getFlashdata('error')): ?>
        <p style="color: red;"><?= session()->getFlashdata('error') ?></p>
    <?php endif; ?>

    <?php if (!empty($schedules)): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>ID Jadwal</th>
                    <th>Tanggal</th>
                    <th>Waktu</th>
                    <th>Nama Psikolog</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($schedules as $schedule): ?>
                    <tr>
                        <td><?= esc($schedule['id']) ?></td>
                        <td><?= esc($schedule['schedule_date']) ?></td>
                        <td><?= esc($schedule['schedule_time']) ?></td>
                        <td><?= esc($schedule['psychologist_name']) ?></td>
                        <td>
                            <!-- Tombol untuk menuju halaman form pemesanan -->
                            <a href="<?= base_url('/book-schedule/'.$schedule['id']) ?>"><button>Pesan</button></a>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Tidak ada jadwal yang tersedia saat ini.</p>
    <?php endif ?>

</body>
</html>
