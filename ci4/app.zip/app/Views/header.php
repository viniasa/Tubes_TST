<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 24px;
        }
        main {
            margin: 20px auto;
            max-width: 800px;
            padding: 20px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            color: #343a40;
        }
        p {
            color: #6c757d;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        ul li {
            margin: 10px 0;
        }
        ul li a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }
        ul li a:hover {
            text-decoration: underline;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .alert {
            padding: 15px;
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        footer {
            text-align: center;
            padding: 10px;
            background-color: #007bff;
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        .menu {
        list-style: none;
        padding: 0;
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
    }
    .menu li {
        flex: 1 1 calc(33.333% - 20px); /* Membagi kolom menjadi tiga */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        overflow: hidden;
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .menu a {
        text-decoration: none;
        color: inherit;
    }
    .menu-item {
        background-color: #ffffff;
        padding: 20px;
        text-align: center;
        border: 1px solid #ddd;
        border-radius: 8px;
    }
    .menu-item h2 {
        font-size: 18px;
        color: #007bff;
        margin-bottom: 10px;
    }
    .menu-item p {
        color: #6c757d;
        font-size: 14px;
    }
    .menu li:hover {
        transform: scale(1.05);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }
    </style>
</head>
<body>
    <header>Welcome to the Online Consultation Booking System</header>
    <main>
        <?php if (session()->get('user_id')): ?> 
            <h1>Welcome, <?= esc(session()->get('name')) ?></h1>
            <p><strong>Username:</strong> <?= esc(session()->get('username')) ?></p>
            <p><strong>Name:</strong> <?= esc(session()->get('name')) ?></p>
            <ul class="menu">
                <li>
                    <a href="<?= base_url('/available-schedules') ?>">
                        <div class="menu-item">
                            <h2>Available Schedules</h2>
                            <p>View and book available consultation schedules.</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="<?= base_url('/bookings') ?>">
                        <div class="menu-item">
                            <h2>Booked Consultations</h2>
                            <p>Check your booked consultations.</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="<?= base_url('/articles') ?>">
                        <div class="menu-item">
                            <h2>Articles</h2>
                            <p>Read articles about mental health.</p>
                        </div>
                    </a>
                </li>
            </ul>
            <a href="<?= site_url('auth/logout') ?>" class="btn">Logout</a>
        <?php else: ?>  
            <div class="alert">You are not logged in.</div>
            <a href="<?= site_url('auth/login') ?>" class="btn">Login</a>
        <?php endif; ?>  