<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Articles</title>
    <style>
        .article-box {
            width: 300px;
            border: 1px solid #ccc;
            margin: 10px;
            padding: 15px;
            text-align: center;
            display: inline-block;
            vertical-align: top;
        }
        .article-box img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>Articles</h1>
    <div>
        <?php foreach ($articles as $article): ?>
            <div class="article-box">
                <img src="<?= esc($article['image']) ?>" alt="<?= esc($article['title']) ?>">
                <h2><?= esc($article['title']) ?></h2>
                <p><?= esc($article['description']) ?></p>
                <a href="<?= esc($article['link']) ?>" target="_blank">Read More</a>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
