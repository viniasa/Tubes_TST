<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>

    <?php if (isset($validation)): ?>
        <ul>
            <?php foreach ($validation->getErrors() as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div style="color: red;"><?= esc($error) ?></div>
    <?php endif; ?>

    <form action="<?= site_url('auth/authenticate') ?>" method="post">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>

    <a href="<?= site_url('auth/forgotPassword') ?>">Lupa Password?</a> | 
    <a href="<?= site_url('auth/signUp') ?>">Daftar Akun Baru</a>
</body>
</html>
