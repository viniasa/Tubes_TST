<p>
    Menu: 
    <a href="/">Dashboard</a> |
    <a href="/about">About</a> |
    <a href="/blog">Blog</a> |
    <a href="/foodmart">Foodmart</a> |
    <a href="/foodmartAPI" target='blank'>FoodmartAPI</a>
</p>