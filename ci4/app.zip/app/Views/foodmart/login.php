<body>  
    <div class="container">  
        <h1>Login</h1>  
        <?php if (session()->getFlashdata('error')): ?>  
        <div class="error"><?= session()->getFlashdata('error') ?></div>  
        <?php endif; ?>  
        
        <form action="/loginUser" method="post">  
            <div class="form-group">  
                <label for="username">Username</label>  
                <input type="text" name="username" id="username" required>  
            </div>      
            <div class="form-group">  
                <label for="password">Password</label>
                <input type="text" name="password" id="password" required>  
            </div>  
            <div class="form-group">  
                <label for="name">Name</label>  
                <input type="text" name="name" id="name" required>  
            </div>  
            <button type="submit">Login</button>  
        </form>  
    </div>  
</body>  

































<!-- <html>  
    <body>  
        <h2>Login</h2>  
        <form action="/login_action"  method="POST">  
            <input type="email" name="email"  placeholder="Email">  
            <input type="password"  name="password"  placeholder="Password">  
            <button type="submit"> Signin</button>  
        </form>  
    </body>  
</html -->