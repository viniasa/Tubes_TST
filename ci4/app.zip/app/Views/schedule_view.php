<?php
// URL endpoint API
$apiUrl = 'http://localhost/schedules';

// Fungsi untuk mendapatkan semua jadwal
function getSchedules($apiUrl)
{
    $response = file_get_contents($apiUrl);
    return json_decode($response, true);
}

// Fungsi untuk menambah jadwal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_schedule'])) {
    $postData = [
        'user_id' => $_POST['user_id'],
        'psychologist_id' => $_POST['psychologist_id'],
        'schedule_date' => $_POST['schedule_date']
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($postData),
        ],
    ];
    $context  = stream_context_create($options);
    $result = file_get_contents($apiUrl, false, $context);
    $message = json_decode($result, true)['message'];
    echo "<script>alert('$message');</script>";
}

// Fungsi untuk menghapus jadwal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_schedule'])) {
    $scheduleId = $_POST['schedule_id'];
    $options = [
        'http' => [
            'method' => 'DELETE',
        ],
    ];
    $context  = stream_context_create($options);
    $result = file_get_contents("$apiUrl/$scheduleId", false, $context);
    $message = json_decode($result, true)['message'];
    echo "<script>alert('$message');</script>";
}

// Mendapatkan daftar jadwal
$schedules = getSchedules($apiUrl);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Konsultasi Psikolog</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
        }
        h1 {
            color: #4CAF50;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .form-container {
            margin-bottom: 20px;
        }
        .form-container input, .form-container button {
            margin-bottom: 10px;
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Jadwal Konsultasi Psikolog</h1>

    <!-- Form Tambah Jadwal -->
    <div class="form-container">
        <h2>Tambah Jadwal Baru</h2>
        <form method="POST">
            <input type="text" name="user_id" placeholder="ID User" required>
            <input type="text" name="psychologist_id" placeholder="ID Psikolog" required>
            <input type="datetime-local" name="schedule_date" placeholder="Tanggal & Waktu Konsultasi" required>
            <button type="submit" name="add_schedule">Tambah Jadwal</button>
        </form>
    </div>

    <!-- Daftar Jadwal -->
    <div>
        <h2>Daftar Jadwal</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Psikolog ID</th>
                    <th>Jadwal</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($schedules['status']): ?>
                    <?php foreach ($schedules['data'] as $schedule): ?>
                        <tr>
                            <td><?= $schedule['id'] ?></td>
                            <td><?= $schedule['user_id'] ?></td>
                            <td><?= $schedule['psychologist_id'] ?></td>
                            <td><?= $schedule['schedule_date'] ?></td>
                            <td><?= $schedule['status'] ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="schedule_id" value="<?= $schedule['id'] ?>">
                                    <button type="submit" name="delete_schedule">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">Belum ada jadwal konsultasi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
