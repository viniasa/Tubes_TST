<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemesanan Jadwal Konsultasi</title>
</head>
<body>
    <h1>Pemesanan Jadwal Konsultasi</h1>

    <h2>Informasi Jadwal</h2>
    <p><strong>Nama Psikolog:</strong> <?= esc($schedule['psychologist_name']) ?></p>
    <p><strong>Tanggal Jadwal:</strong> <?= esc($schedule['schedule_date']) ?></p>
    <p><strong>Waktu:</strong> <?= esc($schedule['schedule_time']) ?></p>

    <form action="<?= base_url('/submit-booking') ?>" method="post">
        <input type="hidden" name="id" value="<?= esc($schedule['id']) ?>">
        <input type="hidden" name="schedule_date" value="<?= esc($schedule['schedule_date']) ?>">
        <input type="hidden" name="schedule_time" value="<?= esc($schedule['schedule_time']) ?>">
        <input type="hidden" name="psychologist_name" value="<?= esc($schedule['psychologist_name']) ?>">

        <label for="user_name">Nama Anda:</label>
        <input type="text" id="user_name" name="user_name" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <button type="submit">Pesan Jadwal</button>
    </form>
</body>
</html>
