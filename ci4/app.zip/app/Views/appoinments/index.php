<?php
// URL endpoint API untuk mendapatkan daftar jadwal
$apiUrl = 'http://localhost/schedules';

// Fungsi untuk mendapatkan data jadwal dari API
function getAppointments($apiUrl) {
    $response = file_get_contents($apiUrl);
    return json_decode($response, true);
}

// Mendapatkan data jadwal
$appointments = getAppointments($apiUrl);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Jadwal Konsultasi Psikolog</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        h1 {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Daftar Jadwal Konsultasi Psikolog</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nama Pengguna</th>
            <th>Nama Psikolog</th>
            <th>Tanggal</th>
            <th>Waktu</th>
            <th>Status</th>
        </tr>
        <?php if (isset($appointments['data']) && is_array($appointments['data'])): ?>
            <?php foreach ($appointments['data'] as $appointment): ?>
            <tr>
                <td><?= htmlspecialchars($appointment['id']); ?></td>
                <td><?= htmlspecialchars($appointment['user_name']); ?></td>
                <td><?= htmlspecialchars($appointment['psychologist_name']); ?></td>
                <td><?= htmlspecialchars($appointment['schedule_date']); ?></td>
                <td><?= htmlspecialchars($appointment['schedule_time']); ?></td>
                <td><?= ucfirst(htmlspecialchars($appointment['status'])); ?></td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">Belum ada jadwal yang terdaftar.</td>
            </tr>
        <?php endif; ?>
    </table>
    <a href="create.php">Buat Jadwal Baru</a>
</body>
</html>
