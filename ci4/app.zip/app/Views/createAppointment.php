<h1>Book a Consultation</h1>

<?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
    <h2>Appointment Confirmation</h2>
    <p>Thank you, <?= esc($_POST['name']); ?>. You have successfully booked a consultation on <?= esc($_POST['date']); ?> at <?= esc($_POST['time']); ?>.</p>
<?php else: ?>
    <form method="POST" action="">
        <label for="name">Full Name: </label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="date">Choose Date: </label><br>
        <input type="date" id="date" name="date" required><br><br>

        <label for="time">Choose Time: </label><br>
        <input type="time" id="time" name="time" required><br><br>

        <button type="submit">Book Consultation</button>
    </form>
<?php endif; ?>
