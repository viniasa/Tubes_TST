<?php

namespace App\Models;

use CodeIgniter\Model;

class ScheduleModel extends Model
{
    protected $table = 'schedules';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id',
        'psychologist_id',
        'schedule_date',
        'status',
        'created_at',
        'updated_at'
    ];
}
