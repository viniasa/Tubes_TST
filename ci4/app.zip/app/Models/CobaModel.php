<?php

namespace App\Models;

use CodeIgniter\Model;

class CobaModel extends Model
{
    protected $table = 'coba'; // Nama tabel
    protected $primaryKey = 'id'; // Primary key
    protected $allowedFields = ['value']; // Kolom yang dapat diisi
}
