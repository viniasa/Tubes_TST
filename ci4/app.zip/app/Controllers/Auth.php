<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    // public function __construct()
    // {
    //     helper(['url', 'form']);
    //     session();
    // }
    
    public function index()
    {
        return view('auth/index');
    }

    public function register()
    {
        return view('auth/register');
    }

    public function storeRegister()
    {
        $userModel = new UserModel();

        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
        ];

        $userModel->save($data);

        return redirect()->to('/auth/login')->with('success', 'Registration successful.');
    }

    public function login()
    {
        return view('auth/login');
    }

    public function attemptLogin()
    {
        $userModel = new UserModel();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $userModel->where('email', $email)->first();

        if ($user && password_verify($password, $user['password'])) {
            session()->set([
                'user_id' => $user['id'],
                'username' => $user['username'],
                'name' => $user['name']
            ]);

            // Debug: Lihat data session
            print_r(session()->get());
            return redirect()->to('/main');
        }

        // Debug: Lihat apakah password/email salah
        echo "Error: Invalid login for email: $email";
        return redirect()->to('/auth/login')->with('error', 'Invalid credentials.');
    }



    public function logout()
    {
        session()->destroy();
        return redirect()->to('/')->with('success', 'Logged out successfully.');
    }

    public function forgetPassword()
    {
        return view('auth/forget_password');
    }

    public function processForgetPassword()
    {
        $userModel = new UserModel();
        $email = $this->request->getPost('email');
        $user = $userModel->where('email', $email)->first();

        if ($user) {
            $token = bin2hex(random_bytes(50));
            $userModel->update($user['id'], ['reset_token' => $token]);

            // Kirim email (simulasi sederhana dengan pesan)
            echo "Token reset password Anda: " . $token;
        }

        return redirect()->to('/auth/login')->with('success', 'Check your email for reset instructions.');
    }

    public function resetPassword($token)
    {
        return view('auth/reset_password', ['token' => $token]);
    }

    public function processResetPassword()
    {
        $userModel = new UserModel();
        $token = $this->request->getPost('token');
        $password = $this->request->getPost('password');

        $user = $userModel->where('reset_token', $token)->first();

        if ($user) {
            $userModel->update($user['id'], [
                'password' => password_hash($password, PASSWORD_BCRYPT),
                'reset_token' => null,
            ]);

            return redirect()->to('/auth/login')->with('success', 'Password reset successful.');
        }

        return redirect()->to('/auth/login')->with('error', 'Invalid reset token.');
    }
}
