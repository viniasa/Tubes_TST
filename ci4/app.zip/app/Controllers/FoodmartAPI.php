<?php
namespace App\Controllers;
use CodeIgniter\RESTful\ResourceController;
use App\Models\Foodmart;

class FoodmartAPI extends ResourceController{
    public function index(){
        $model = new CustomerQuery();
        $querysaya = "SELECT * FROM view_sales_fact_1997 WHERE
                    fname LIKE '%now%' OR
                    lname LIKE '%now%' OR
                    mi LIKE '%now%'
                    ORDER BY fname ASC
                    LIMIT 10";
        $data['view_sales_fact_19997'] = $model->query($querysaya)->getResult();
        $data = $model->getDataFoodmart();
        return $this->respond($data, 200);
    }
}