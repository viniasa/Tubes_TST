<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\CobaModel;

class CobaController extends ResourceController
{
    // public function insertData()
    // {
    //     $model = new CobaModel();
        
    //     // Ambil data dari body request
    //     $input = $this->request->getPost();

    //     // Validasi data
    //     if (!isset($input['value']) || empty($input['value'])) {
    //         return $this->respond(['message' => 'Value is required'], 400);
    //     }

    //     // Masukkan data ke database
    //     $data = [
    //         'value' => $input['value']
    //     ];
    //     $model->insert($data);

    //     return $this->respond(['message' => 'Data inserted successfully'], 201);
    // }

    use \CodeIgniter\API\ResponseTrait;
    
    protected $modelName = 'App\Models\CobaModel';
    protected $format    = 'json';

    public function delete($id=null)
    {
        // Validasi apakah ID valid (angka)
        if (!is_numeric($id)) {
            return $this->respond(['status' => 'error', 'message' => 'ID tidak valid'], 400);
        }

        // Periksa apakah data dengan ID tersebut ada
        if ($this->model->find($id)) {
            // Hapus data
            $this->model->delete($id);
            return $this->respond(['status' => 'success', 'message' => 'Data berhasil dihapus'], 200);
        } else {
            return $this->respond(['status' => 'error', 'message' => 'Data tidak ditemukan'], 404);
        }
    }

    public function update($id = null)
    {
        // Validasi apakah ID valid
        if (!is_numeric($id)) {
            return $this->respond(['status' => 'error', 'message' => 'ID tidak valid'], 400);
        }

        // Ambil data dari body request
        $input = $this->request->getJSON(true);// Mengambil data JSON
        if (!isset($input['value']) || empty($input['value'])) {
            return $this->respond(['status' => 'error', 'message' => 'Value is required'], 400);
        }

        // Periksa apakah data dengan ID tersebut ada
        $data = $this->model->find($id);
        if (!$data) {
            return $this->respond(['status' => 'error', 'message' => 'Data tidak ditemukan'], 404);
        }

        // Update data
        $updateData = ['value' => $input['value']];
        $this->model->update($id, $updateData);

        return $this->respond(['status' => 'success', 'message' => 'Data berhasil diupdate'], 200);
    }

    
}
