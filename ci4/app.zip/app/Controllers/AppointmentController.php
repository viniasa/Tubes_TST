<?php

namespace App\Controllers;

use App\Models\AppointmentModel;
use CodeIgniter\RESTful\ResourceController;

class AppointmentController extends ResourceController
{
    protected $modelName = 'App\Models\AppointmentModel';
    protected $format = 'json';

    public function index()
    {
        // $appointments = $this->model->findAll();
        // return $this->respond($appointments);

        $appointmentModel = new AppointmentModel();
        $appointments = $appointmentModel->findAll();
        // return view('appointments/index', ['appointments' => $appointments]);
        return view('header').view('footer');
    }

    public function avail()
    {
        // Load model
        $appointmentModel = new AppointmentModel();

        // Ambil data jadwal yang tersedia
        $availableSchedules = $appointmentModel->getAvailableSchedules();

        // Pass data ke view
        return view('available_schedules', ['schedules' => $availableSchedules]);
    }

    public function bookSchedule($id)
    {
        $appointmentModel = new AppointmentModel();
        // Ambil data jadwal berdasarkan ID
        $schedule = $appointmentModel->find($id);
        
        if (!$schedule) {
            return redirect()->to('/available-schedules')->with('error', 'Jadwal tidak ditemukan');
        }

        // Tampilkan form pemesanan
        return view('booking_form', ['schedule' => $schedule]);
    }

    // Mengirimkan pemesanan
    // Controller: AppointmentController.php
    public function submitBooking()
    {
        $session = session();

        // Pastikan pengguna sudah login
        if (!$session->has('user_id')) {
            return redirect()->to('/auth/login')->with('error', 'Please log in first.');
        } 
        
        // Ambil data dari form
        $data = [
            'user_id' => $session->get('user_id'),  // Ambil user_id dari session
            'user_name' => $this->request->getPost('user_name'),
            'email' => $this->request->getPost('email'),
            'psychologist_name' => $this->request->getPost('psychologist_name'),
            'schedule_date' => $this->request->getPost('schedule_date'),
            'schedule_time' => $this->request->getPost('schedule_time'),
            'status' => 'booked', // Status pemesanan
        ];

        $appointmentModel = new AppointmentModel();
        $id = $this->request->getPost('id'); // Ambil ID jadwal dari form

        // Cek jika ID dan data valid
        if (!$id) {
            return redirect()->to('/available-schedules')->with('error', 'ID Jadwal tidak valid');
        }

        // Update status jadwal menjadi 'booked'
        if ($appointmentModel->bookAppointment($id, $data)) {
            return redirect()->to('/available-schedules')->with('success', 'Jadwal berhasil dipesan');
        }

        return redirect()->back()->with('error', 'Gagal memesan jadwal');
    }

    public function showBookings()
    {
        $session = session();

        // Pastikan user sudah login
        if (!$session->has('user_id')) {
            return redirect()->to('/auth/login')->with('error', 'Please log in first.');
        }

        $userId = $session->get('user_id');  // Ambil user_id dari session

        // Inisialisasi model dan ambil semua pemesanan untuk user ini
        $appointmentModel = new AppointmentModel();
        $bookedAppointments = $appointmentModel->where('user_id', $userId)->where('status', 'booked')->findAll();  // Filter berdasarkan user_id

        return view('bookings_view', ['bookedAppointments' => $bookedAppointments]);
    }


    public function cancelBooking()
    {
        $session = session();

        if (!$session->has('user_id')) {
            return redirect()->to('/auth/login')->with('error', 'Please log in first.');
        }

        $id = $this->request->getPost('id');
        $appointmentModel = new AppointmentModel();

        // Pastikan hanya user yang memiliki booking ini yang bisa membatalkannya
        $appointment = $appointmentModel->find($id);
        if ($appointment && $appointment['user_id'] == $session->get('user_id')) {
            // Update status booking menjadi available
            if ($appointmentModel->update($id, ['status' => 'available'])) {
                return redirect()->to('/main')->with('success', 'Booking successfully canceled.');
            }
        }

        return redirect()->to('/bookings')->with('error', 'Failed to cancel booking or you don\'t have permission.');
    }
    


}
