<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{
    public function index()
    {
        return view('auth/index');
    }
    
    // Fungsi untuk tampilan Sign Up
    public function signUp()
    {
        return view('auth/sign_up');
    }

    // Fungsi untuk memproses Sign Up
    public function register()
    {
        $validation = \Config\Services::validation();

        // Validasi input
        $rules = [
            'username' => 'required|min_length[5]|max_length[20]',
            'email' => 'required|valid_email',
            'password' => 'required|min_length[6]',
            'confirm_password' => 'matches[password]',
        ];

        if (!$this->validate($rules)) {
            return view('auth/sign_up', [
                'validation' => $this->validator,
            ]);
        }

        // Menyimpan data user ke database
        $userModel = new UserModel();
        $userModel->save([
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ]);

        return redirect()->to('/login')->with('success', 'Registrasi berhasil, silakan login.');
    }

    // Fungsi untuk tampilan Login
    public function login()
    {
        return view('auth/login');
    }

    // Fungsi untuk memproses Login
    public function authenticate()
    {
        $validation = \Config\Services::validation();

        $rules = [
            'email' => 'required|valid_email',
            'password' => 'required',
        ];

        if (!$this->validate($rules)) {
            return view('auth/login', [
                'validation' => $this->validator,
            ]);
        }

        $userModel = new UserModel();
        $user = $userModel->where('email', $this->request->getPost('email'))->first();

        if ($user && password_verify($this->request->getPost('password'), $user['password'])) {
            session()->set('user_id', $user['id']);
            session()->set('username', $user['username']);
            return redirect()->to('/home');
        }

        return view('auth/login', [
            'error' => 'Email atau password salah.',
        ]);
    }

    // Fungsi untuk Logout
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }

    // Fungsi untuk tampilan Forgot Password
    public function forgotPassword()
    {
        return view('auth/forgot_password');
    }

    // Fungsi untuk memproses Forgot Password
    public function resetPassword()
    {
        $validation = \Config\Services::validation();

        $rules = [
            'email' => 'required|valid_email',
        ];

        if (!$this->validate($rules)) {
            return view('auth/forgot_password', [
                'validation' => $this->validator,
            ]);
        }

        $userModel = new UserModel();
        $user = $userModel->where('email', $this->request->getPost('email'))->first();

        if ($user) {
            // Di sini, buat mekanisme reset password (misalnya, kirim email untuk reset)
            return redirect()->to('/login')->with('success', 'Email reset password sudah dikirim.');
        }

        return view('auth/forgot_password', [
            'error' => 'Email tidak ditemukan.',
        ]);
    }
}

