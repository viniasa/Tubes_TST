<?php

namespace App\Controllers;

use App\Models\UserModel;

class UserController extends BaseController
{
    // Fungsi untuk menampilkan halaman utama
    public function index()
    {
        // Mengecek apakah pengguna sudah login atau belum
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/dashboard'); // Halaman dashboard setelah login
        } else {
            return view('start'); // Menampilkan halaman utama
        }
    }

    // Fungsi untuk tampilan form sign up
    public function signup()
    {
        return view('signup');
    }

    // Fungsi untuk proses sign up
    public function createUser()
    {
        $validation =  \Config\Services::validation();

        if ($this->validate([
            'username' => 'required|min_length[3]|max_length[20]|is_unique[users.username]',
            'password' => 'required|min_length[8]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'name' => 'required|min_length[3]',
        ])) {
            // Mengambil input dari form
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');
            $name = $this->request->getPost('name');
            $email = $this->request->getPost('email');
            
            // Hash password sebelum disimpan
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $userModel = new UserModel();
            $userModel->save([
                'username' => $username,
                'password' => $hashedPassword,
                'name' => $name,
                'email' => $email
            ]);
            
            return redirect()->to('/login')->with('success', 'Account created successfully!');
        } else {
            return redirect()->to('/signup')->with('error', 'Validation failed!')->withInput();
        }
    }

    // Fungsi untuk tampilan form login
    public function login()
    {
        return view('login');
    }

    // Fungsi untuk proses login
    public function loginUser()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $userModel = new UserModel();
        $user = $userModel->where('username', $username)->first();

        if ($user && password_verify($password, $user['password'])) {
            session()->set([
                'username' => $user['username'],
                'name' => $user['name'],
                'isLoggedIn' => true
            ]);
            return redirect()->to('/dashboard');
        } else {
            return redirect()->to('/login')->with('error', 'Invalid username or password.');
        }
    }

    // Fungsi untuk logout
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }

    // Fungsi untuk tampilkan form forgot password
    public function forgotPassword()
    {
        return view('forgot_password');
    }

    // Fungsi untuk proses forgot password
    public function resetPassword()
    {
        $email = $this->request->getPost('email');
        $userModel = new UserModel();
        $user = $userModel->where('email', $email)->first();

        if ($user) {
            // Generate token and send email (for simplicity, this is a placeholder)
            $token = bin2hex(random_bytes(50));

            // Simulate sending email with reset link
            echo 'Reset link sent to your email: ' . base_url('reset-password/' .$token);
        } else {
            return redirect()->to('/forgot-password')->with('error', 'Email not found.');
        }
    }

    // Fungsi untuk reset password
    public function resetPasswordForm($token)
    {
        // Placeholder for token validation
        return view('reset_password');
    }

    // Fungsi untuk update password setelah reset
    public function updatePassword()
    {
        $password = $this->request->getPost('password');
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Update password logic goes here
    }
}
