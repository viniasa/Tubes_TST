<?php
namespace App\Controllers;
use CodeIgniter\RESTful\ResourceController;
use App\Models\CustomerQuery;
class CustomerControllerQuery extends ResourceController
{
    public function searchParamAPI($x)
    {
        $model = new CustomerQuery();
        $querysaya = 'SELECT * FROM customer
                      WHERE fname LIKE "%'.$x.'%" OR
                      lname LIKE "%'.$x.'%" OR
                      mi LIKE "%'.$x.'%" ORDER BY fname ASC
                      LIMIT 10';
        $data['customers'] = $model->query($querysaya)->getResult();
        return $this->respond($data,200);
    }
}