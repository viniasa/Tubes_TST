<?php

namespace App\Controllers;

use App\Models\ScheduleModel;
use CodeIgniter\RESTful\ResourceController;

class ScheduleController extends ResourceController
{
    protected $modelName = 'App\Models\ScheduleModel';
    protected $format    = 'json';

    // CREATE: Tambah Jadwal
    public function create()
    {
        $data = $this->request->getJSON(true);
        $insertData = [
            'user_id' => $data['user_id'],
            'psychologist_id' => $data['psychologist_id'],
            'schedule_date' => $data['schedule_date'],
            'status' => 'pending',
        ];

        if ($this->model->insert($insertData)) {
            return $this->respondCreated([
                'status' => true,
                'message' => 'Jadwal konsultasi berhasil dipesan',
                'data' => $insertData
            ]);
        }

        return $this->fail('Gagal memesan jadwal');
    }

    // READ: Lihat Semua Jadwal
    public function index()
    {
        $schedules = $this->model->findAll();
        // return $this->respond([
        //     'status' => true,
        //     'data' => $schedules
        // ]);
        return view('schedule_view');
        

        
    }

    // READ: Lihat Detail Jadwal
    public function show($id = null)
    {
        $schedule = $this->model->find($id);
        if ($schedule) {
            return $this->respond([
                'status' => true,
                'data' => $schedule
            ]);
        }

        return $this->failNotFound('Jadwal tidak ditemukan');
    }

    // UPDATE: Ubah Jadwal
    public function update($id = null)
    {
        $data = $this->request->getJSON(true);
        if ($this->model->update($id, $data)) {
            return $this->respondUpdated([
                'status' => true,
                'message' => 'Jadwal berhasil diperbarui',
                'data' => $data
            ]);
        }

        return $this->fail('Gagal memperbarui jadwal');
    }

    // DELETE: Hapus Jadwal
    public function delete($id = null)
    {
        if ($this->model->delete($id)) {
            return $this->respondDeleted([
                'status' => true,
                'message' => 'Jadwal berhasil dihapus'
            ]);
        }

        return $this->fail('Gagal menghapus jadwal');
    }
}
