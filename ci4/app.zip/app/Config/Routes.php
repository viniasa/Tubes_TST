<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

//  $routes->group('schedules', ['namespace' => 'App\Controllers'], function ($routes) {
//     $routes->get('/', 'ScheduleController::index');
//     $routes->get('(:num)', 'ScheduleController::show/$1');
//     $routes->post('/', 'ScheduleController::create');
//     $routes->put('(:num)', 'ScheduleController::update/$1');
//     $routes->delete('(:num)', 'ScheduleController::delete/$1');
// });

// $routes->get('/', 'Home::index');
// $routes->get('/about', 'About::index');
// $routes->get('/blog', 'Blog::index');
// $routes->get('/foodmart', 'FoodmartController::index');
// $routes->post('/coba/insert', 'CobaController::insertData');
// $routes->get('/queryAPI/(:any)', 'CustomerControllerQuery::searchParamAPI/$1');
// $routes->get('/logout', 'LoginController::logout');
// $routes->get('/login_action', 'LoginController::login_action');
// $routes->get('(:any)/(:any)/(:any)', 'UserController::getUser/$1/$2/$3');
// $routes->delete('coba/(:num)', 'CobaController::delete/$1');
// $routes->put('coba/(:num)', 'CobaController::update/$1');
// $routes->get('/login', 'UserController::login');
// $routes->post('/loginUser', 'UserController::loginUser');

$routes->get('/main', 'AppointmentController::index');
$routes->get('/available-schedules', 'AppointmentController::avail');
$routes->get('/book-schedule/(:num)', 'AppointmentController::bookSchedule/$1');
$routes->post('/submit-booking', 'AppointmentController::submitBooking');
$routes->get('/bookings', 'AppointmentController::showBookings');
$routes->post('/cancel-booking', 'AppointmentController::cancelBooking');

$routes->get('/auth/register', 'Auth::register');
$routes->post('/auth/storeRegister', 'Auth::storeRegister');
$routes->get('/auth/login', 'Auth::login');
$routes->post('/auth/attemptLogin', 'Auth::attemptLogin');
$routes->get('/auth/logout', 'Auth::logout');
$routes->get('/auth/forgetPassword', 'Auth::forgetPassword');
$routes->post('/auth/processForgetPassword', 'Auth::processForgetPassword');
$routes->get('/auth/resetPassword/(:any)', 'Auth::resetPassword/$1');
$routes->post('/auth/processResetPassword', 'Auth::processResetPassword');
// $routes->get('/main', function () {
//     echo "Welcome to the main page!";
// });
$routes->get('/', 'Auth::index'); // Route untuk halaman utama
$routes->get('/articles', 'ArticleController::index');













